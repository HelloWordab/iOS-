//
//  UIImage+YXBlur.h
//  模糊工具
//
//  Created by admin on 16/12/20.
//  Copyright © 2016年 Poco.yyx. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Accelerate/Accelerate.h>

@interface UIImage (YXBlur)

/*!
 *  高斯模糊修改颜色　半径 饱和度 添加遮罩
 *  @param blur                     模糊程度(0 - 1)超过的均默认为 0.5
 *  @param blurRadius               模糊半径 推荐 30 - 40
 *  @param tintColor                模糊颜色 (null)推荐制空
 *  @param saturationDeltaFactor    饱和度 0是黑白灰, 9是浓彩色, 1是原色  默认1.8
 *  @param maskImage                遮罩
 */
- (UIImage *)imageBluredwithBlurNumber:(CGFloat)blur WithRadius:(CGFloat)blurRadius  tintColor:(UIColor *)tintColor saturationDeltaFactor:(CGFloat)saturationDeltaFactor maskImage:(UIImage *)maskImage;

/*!
 *  默认颜色下的高斯模糊
 *  @param blur    模糊程度(0 - 1)超过的均默认为 0.5
 *  @param radius    模糊半径 推荐 30 - 40
 */
- (UIImage *)imageBoxblurwithBlurNumber:(CGFloat)blur withBlurRadius:(float)radius;

/*!
 *  毛玻璃效果基于UIToolbar
 *  iOS7.0
 *  @param imageView   要渲染的图片视图
 *  @param BarStyle    毛玻璃的类型总共有4种
 *  @param GGRect      毛玻璃的范围
 */
- (void)groundGlassBaseToolbarWithImageView:(UIImageView *)imageView barStyle:(UIBarStyle)BarStyle groundGlassFrame:(CGRect)GGRect;

/*!
 *  毛玻璃效果基于UIVisualEffectView
 *  iOS8.0
 *  @param imageView   要渲染的图片视图
 *  @param BlurEffectStyle    毛玻璃的类型总共有4种
 *  @param GGRect      毛玻璃的范围
 */
- (void)groundGlassBaseVisualEffectWithImageView:(UIImageView *)imageView barStyle:(UIBlurEffectStyle)BlurEffectStyle groundGlassFrame:(CGRect)GGRect;
@end
