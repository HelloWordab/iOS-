//
//  ViewController.m
//  模糊工具
//
//  Created by admin on 16/12/19.
//  Copyright © 2016年 Poco.yyx. All rights reserved.
//

#import "ViewController.h"
#import "UIImage+YXBlur.h"

@interface ViewController ()<UIImagePickerControllerDelegate,UINavigationControllerDelegate>

@property (nonatomic,copy) UIImageView *imageView; //图片
@property (nonatomic,copy) UISlider *sliderView; //模糊度进度条;
@property (nonatomic,copy) UISlider *sliderViewRadius; //半径进度条;
@property (nonatomic,copy) UISlider *sliderViewSaturationDeltaFactor; //饱和度
@property (nonatomic) float radius; // ( 模糊半径 )
@property (nonatomic) float blur; // 模糊程度 (0 - 1 )
@property (nonatomic) float saturation ; //饱和度
@property (nonatomic,copy) UIImage *image;//模糊图片
@property (nonatomic,copy) UIImage *maskImage; //遮罩
@property (nonatomic,strong) UIButton *button; //选图
@property (nonatomic,strong) UIButton *buttonMask; //选图
@property (nonatomic) BOOL isMaskImage;//标示
@property (nonatomic,copy) UIImagePickerController *pickerController;//系统相册
@property (nonatomic, nonnull,strong) UIButton *buttonUpdown;//关闭按钮
@property (nonatomic) BOOL isExchange;//更换模式的标示
@property (nonatomic,copy) UILabel *labelWelcome;//欢迎
@property (nonatomic,copy) UIView *ballView;//弹框视图
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    _radius = 0.4;
    _saturation = 1;
    _isMaskImage = NO;
    _isExchange = NO;
    [self.view addSubview:self.imageView];
    [self layoutView];
}

//布局
- (void)layoutView{
    [self.view addSubview:self.labelWelcome];
    [self.view addSubview:self.ballView];
   
}

//懒加载
- (UIImageView *)imageView{
    if (!_imageView) {
        _imageView = [[UIImageView alloc]initWithFrame:CGRectMake(0, 20, CGRectGetWidth(self.view.bounds), CGRectGetHeight(self.view.bounds))];
        _imageView.contentMode = UIViewContentModeScaleAspectFit;
        
#pragma  mark- 创建缩放手势
        _imageView.userInteractionEnabled = YES;
        UIPinchGestureRecognizer *pinch = [[UIPinchGestureRecognizer alloc]initWithTarget:self action:@selector(pinchPic:)];
        [_imageView addGestureRecognizer:pinch];
        
#pragma mark- 拖拽手势
        UIPanGestureRecognizer *pan = [[UIPanGestureRecognizer alloc]initWithTarget:self action:@selector(panPic:)];
        [_imageView addGestureRecognizer:pan];
        
#pragma mark- 点击手势
        UITapGestureRecognizer *tapG = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(updownBlurValue)];
        [_imageView addGestureRecognizer:tapG];
    }
    
    return _imageView;
}
- (UILabel *)labelWelcome{
    if (!_labelWelcome) {
        _labelWelcome = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, 200, 20)];
        _labelWelcome.center = self.view.center;
        _labelWelcome.text = @"欢迎使用模糊工具";
        _labelWelcome.font = [UIFont systemFontOfSize:20];
        _labelWelcome.textAlignment = NSTextAlignmentCenter;
        _labelWelcome.textColor = [UIColor orangeColor];
    }
    
    return _labelWelcome;
}

- (UIView *)ballView{
    if (!_ballView) {
        _ballView = [[UIView alloc] initWithFrame:CGRectMake(0, CGRectGetHeight(self.view.bounds) - 200, CGRectGetWidth(self.view.bounds), 200)];
        _ballView.backgroundColor = [UIColor lightGrayColor];
        [_ballView addSubview:self.button];
        [_ballView addSubview:self.buttonMask];
        UIButton *butoonExchange = [UIButton buttonWithType:UIButtonTypeCustom];
        butoonExchange.frame = CGRectMake(30, 30, 100, 20);
        butoonExchange.backgroundColor = [UIColor cyanColor];
        [butoonExchange setTitle:@"高斯模糊" forState:UIControlStateNormal];
        [butoonExchange addTarget:self action:@selector(exchageBlurValue:) forControlEvents:UIControlEventTouchDown];
        [_ballView addSubview:butoonExchange];
        [_ballView addSubview:self.buttonUpdown];
        _ballView.userInteractionEnabled = YES;
        UITapGestureRecognizer *tapG = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(touchBaliViewValue)];
        tapG.numberOfTapsRequired = 1;
        tapG.numberOfTouchesRequired = 1;
        [_ballView addGestureRecognizer:tapG];
        [_ballView addSubview:self.sliderView];
        [_ballView addSubview:self.sliderViewRadius];
        [_ballView addSubview:self.sliderViewSaturationDeltaFactor];
        UILabel *labeBlur = [[UILabel alloc]initWithFrame:
                             CGRectMake(350, 100, 150, 10)];
        labeBlur.text = @"模糊度";
        [_ballView addSubview:labeBlur];
        UILabel *labeSaturationDeltaFactor = [[UILabel alloc]initWithFrame:
                                              CGRectMake(350, 130, 150, 10)];
        labeSaturationDeltaFactor.text = @"半径";
        [_ballView addSubview:labeSaturationDeltaFactor];
        UILabel *labeBlurRadius = [[UILabel alloc]initWithFrame:
                                   CGRectMake(350, 160, 150, 10)];
        labeBlurRadius.text = @"饱和度";
        [_ballView addSubview:labeBlurRadius];

    }
    
    return _ballView;
}

- (UIButton *)button{
    if (!_button) {
        _button = [UIButton buttonWithType:UIButtonTypeCustom];
        _button.frame = CGRectMake(30, 60, 150, 30);
        [_button addTarget:self action:@selector(addImageValue) forControlEvents:UIControlEventTouchDown];
        [_button setTitle:@"添加底图" forState:UIControlStateNormal];
        _button.contentMode = UIViewContentModeScaleToFill;
        _button.backgroundColor = [UIColor cyanColor];
        
    }
    
    return _button;
}

- (UIButton *)buttonMask{
    if (!_buttonMask) {
        _buttonMask = [UIButton buttonWithType:UIButtonTypeCustom];
        _buttonMask.frame = CGRectMake(CGRectGetWidth(self.view.bounds) - 180, 60, 150, 30);
        [_buttonMask addTarget:self action:@selector(addImageValueMask) forControlEvents:UIControlEventTouchDown];
        [_buttonMask setTitle:@"添加遮罩" forState:UIControlStateNormal];
        _buttonMask.contentMode = UIViewContentModeScaleToFill;
        _buttonMask.backgroundColor=  [UIColor cyanColor];
        
    }
    
    return _buttonMask;
}

- (UIImagePickerController *)pickerController{
    if (!_pickerController) {
        _pickerController = [[UIImagePickerController alloc]init];
        _pickerController.delegate = self;
        _pickerController.allowsEditing = YES;
    }
    
    return _pickerController;
}
- (UISlider *)sliderView{
    if (!_sliderView) {
        _sliderView = [[UISlider alloc]initWithFrame:CGRectMake(30, 100, 300, 10)];
        _sliderView.thumbTintColor = [UIColor cyanColor];
        _sliderView.minimumTrackTintColor = [UIColor greenColor];
        _sliderView.maximumTrackTintColor = [UIColor blueColor];
        _sliderView.minimumValue = 0;
        _sliderView.maximumValue = 1;
        
        //加事件
        [_sliderView addTarget:self action:@selector(sliderMe:) forControlEvents:UIControlEventValueChanged];
    }
    
    return _sliderView;
}

- (UISlider *)sliderViewRadius{
    if (!_sliderViewRadius) {
        _sliderViewRadius = [[UISlider alloc]initWithFrame:CGRectMake(30, 130, 300, 10)];
        _sliderViewRadius.thumbTintColor = [UIColor cyanColor];
        _sliderViewRadius.minimumTrackTintColor = [UIColor greenColor];
        _sliderViewRadius.maximumTrackTintColor = [UIColor blueColor];
        _sliderViewRadius.minimumValue = 0;
        _sliderViewRadius.maximumValue = 1;
        
        //加事件
        [_sliderViewRadius addTarget:self action:@selector(sliderMeRadius:) forControlEvents:UIControlEventValueChanged];
    }
    
    return _sliderViewRadius;
}
- (UISlider *)sliderViewSaturationDeltaFactor{
    if (!_sliderViewSaturationDeltaFactor) {
        _sliderViewSaturationDeltaFactor = [[UISlider alloc]initWithFrame:CGRectMake(30, 160, 300, 10)];
        _sliderViewSaturationDeltaFactor.thumbTintColor = [UIColor cyanColor];
        _sliderViewSaturationDeltaFactor.minimumTrackTintColor = [UIColor greenColor];
        _sliderViewSaturationDeltaFactor.maximumTrackTintColor = [UIColor blueColor];
        _sliderViewSaturationDeltaFactor.minimumValue = 0;
        _sliderViewSaturationDeltaFactor.maximumValue = 1;
        _sliderViewSaturationDeltaFactor.value = 0.1;
        
        //加事件
        [_sliderViewSaturationDeltaFactor addTarget:self action:@selector(sliderMesaturationDeltaFactor:) forControlEvents:UIControlEventValueChanged];
    }
    
    return _sliderViewSaturationDeltaFactor;
}

- (UIButton *)buttonUpdown{
    if (!_buttonUpdown) {
        _buttonUpdown = [UIButton buttonWithType:UIButtonTypeCustom];
        _buttonUpdown.frame = CGRectMake(CGRectGetWidth(self.view.bounds) - 60,30, 40, 20);
        _buttonUpdown.backgroundColor = [UIColor cyanColor];
        [_buttonUpdown setTitle:@"下滑" forState:UIControlStateNormal];
        [_buttonUpdown addTarget:self action:@selector(updownBlurValue) forControlEvents:UIControlEventTouchDown];
    }
    
    return _buttonUpdown;
}


//缩放
-(void)pinchPic:(UIPinchGestureRecognizer *)pinch{
    
    //获取要缩放的视图
    UIImageView *imageVI = (UIImageView *)pinch.view;
    imageVI.transform = CGAffineTransformScale(imageVI.transform, pinch.scale, pinch.scale);
    pinch.scale = 1;
}

//拖拽的方法
-(void)panPic:(UIPanGestureRecognizer *)pan{
    UIImageView *viewI = (UIImageView *)pan.view;
    CGPoint point =[pan translationInView:viewI];
    viewI.transform = CGAffineTransformTranslate(viewI.transform, point.x, point.y );
    
    //还原
    [pan setTranslation:CGPointZero inView:viewI];
}

//选图
- (void)addImageValue{
    self.labelWelcome.hidden = YES;
    _isMaskImage = NO;
    [self presentViewController:self.pickerController animated:YES completion:nil];
}
- (void)addImageValueMask{
    self.labelWelcome.hidden = YES;
    _isMaskImage = YES;
    [self presentViewController:self.pickerController animated:YES completion:nil];
}

#pragma mark- uiimagePickerController 的代理
- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary<NSString *,id> *)info{
    
    //根据是否点击的是遮罩按钮选择获得图片进行赋值
    if (_isMaskImage) {
        self.maskImage = [info objectForKey:@"UIImagePickerControllerEditedImage"];
        
    } else {
        self.image = [info objectForKey:@"UIImagePickerControllerEditedImage"];
    }
    
    [self dismissViewControllerAnimated:YES completion:^{}];
    
    //根据是否改变了模型来选择图层处理
    if (_isExchange) {
        [self showGroundGlass];
    } else {
        [self showBlurView];
    }

}

//更换模糊类型
- (void)exchageBlurValue:(UIButton *)button {
    if (!_isExchange) {
        [button setTitle:@"毛玻璃" forState:UIControlStateNormal];
        self.buttonMask.hidden = YES;
        [self.image groundGlassBaseVisualEffectWithImageView:self.imageView
                                                    barStyle:UIBlurEffectStyleLight
                                            groundGlassFrame:self.imageView.bounds];

    } else {
        [button setTitle:@"高斯模糊" forState:UIControlStateNormal];
        self.buttonMask.hidden = NO;
        for (UIView *view in self.imageView.subviews) {
            if ([view isKindOfClass:[UIVisualEffectView class]]) {
                [view removeFromSuperview];
            }
        }
        [self.image imageBluredwithBlurNumber:_blur WithRadius:_radius*100 tintColor:NULL saturationDeltaFactor:_saturation maskImage:self.maskImage];
    }
    
    _isExchange = !_isExchange;
}

//显示毛玻璃
- (void)showGroundGlass{
    self.imageView.image = self.image;
    [self.image groundGlassBaseVisualEffectWithImageView:self.imageView
                                                barStyle:UIBlurEffectStyleLight
                                        groundGlassFrame:self.imageView.bounds];
}

//显示模糊试图
- (void)showBlurView{
    for (UIView *view in self.imageView.subviews) {
        if ([view isKindOfClass:[UIVisualEffectView class]]) {
            [view removeFromSuperview];
        }
    }
    
    self.imageView.image = [self.image imageBluredwithBlurNumber:_blur
                                                      WithRadius:_radius*100
                                                       tintColor:NULL
                                           saturationDeltaFactor:_saturation
                                                       maskImage:self.maskImage];
}


//模糊度
- (void)sliderMe:(UISlider *)sliderView{
    _blur = sliderView.value;
    self.imageView.image = [self.image imageBluredwithBlurNumber:sliderView.value
                                                      WithRadius:_radius*100
                                                       tintColor:NULL
                                           saturationDeltaFactor:_saturation
                                                       maskImage:self.maskImage];
}

//模糊半径
- (void)sliderMeRadius:(UISlider *)sliderView{
    _radius = sliderView.value;
    self.imageView.image = [self.image imageBluredwithBlurNumber:_blur
                                                      WithRadius:_radius*100
                                                       tintColor:NULL
                                           saturationDeltaFactor:_saturation
                                                       maskImage:self.maskImage];
}

//模糊饱和度
- (void)sliderMesaturationDeltaFactor:(UISlider *)sliderView{
    _saturation = sliderView.value*10;
    self.imageView.image = [self.image imageBluredwithBlurNumber:_blur
                                                      WithRadius:_radius*100
                                                       tintColor:NULL
                                           saturationDeltaFactor:_saturation
                                                       maskImage:self.maskImage];
    
}

//下滑
- (void)updownBlurValue{
    [UIView animateWithDuration:0.3f animations:^{
        self.ballView.frame = CGRectMake(0, CGRectGetHeight(self.view.bounds) - 30, CGRectGetWidth(self.view.bounds), 200);
    } completion:^(BOOL finished) {
        
    }];
}

- (void)touchBaliViewValue{
    [UIView animateWithDuration:0.3f animations:^{
        self.ballView.frame = CGRectMake(0, CGRectGetHeight(self.view.bounds) - 200, CGRectGetWidth(self.view.bounds), 200);
    } completion:^(BOOL finished) {}];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
